package followschema

type RecursiveInputSlice struct {
	Self []RecursiveInputSlice
}
