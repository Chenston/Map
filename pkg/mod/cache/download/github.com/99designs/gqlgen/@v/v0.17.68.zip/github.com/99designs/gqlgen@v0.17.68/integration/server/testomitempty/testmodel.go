package testomitempty

type RemoteModelWithOmitempty struct {
	Description string `json:"newDesc,omitempty"`
}
