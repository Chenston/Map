package singlefile

type PtrToSliceContainer struct {
	PtrToSlice *[]string
}
