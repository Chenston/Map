package invalid_packagename

type InvalidIdentifier struct {
	ID int
}
