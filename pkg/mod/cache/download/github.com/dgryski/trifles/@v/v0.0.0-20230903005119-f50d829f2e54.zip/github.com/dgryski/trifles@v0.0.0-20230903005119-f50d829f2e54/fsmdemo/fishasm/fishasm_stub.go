package fishasm

//go:noescape
func Match(data string) int
