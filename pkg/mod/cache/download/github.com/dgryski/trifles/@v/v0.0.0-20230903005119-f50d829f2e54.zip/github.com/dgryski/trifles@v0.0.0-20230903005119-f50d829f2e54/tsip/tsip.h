uint64_t tsip(const unsigned char *seed, const unsigned char *message, size_t len);

