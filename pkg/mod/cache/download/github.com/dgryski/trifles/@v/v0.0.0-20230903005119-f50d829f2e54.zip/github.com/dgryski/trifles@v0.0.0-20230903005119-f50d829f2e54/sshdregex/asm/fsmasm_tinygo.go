//go:build wasi || wasip1 || tinygo

package asm

func Match(data []byte) int {
	return 0
}
