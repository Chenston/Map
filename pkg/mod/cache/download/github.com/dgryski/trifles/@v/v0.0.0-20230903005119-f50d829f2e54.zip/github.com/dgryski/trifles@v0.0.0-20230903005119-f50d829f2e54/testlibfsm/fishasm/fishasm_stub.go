package fishasm

//go:noescape
func Match(data []byte) int
