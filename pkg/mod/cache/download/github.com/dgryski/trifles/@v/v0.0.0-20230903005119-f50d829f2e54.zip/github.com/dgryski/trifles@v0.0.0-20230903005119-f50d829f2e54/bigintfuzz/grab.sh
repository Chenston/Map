#!/bin/sh
curl -O https://raw.githubusercontent.com/gonzus/bigint/master/bigint.c
curl -O https://raw.githubusercontent.com/gonzus/bigint/master/bigint.h
